﻿using System;

namespace GenericArrayCreator
{
    class StartUp
    {
        static void Main(string[] args)
        {
            string[] name = ArrayCreator.Create(5, "Pesho");
        }
    }
}
