﻿using System;

namespace CarManufacturer
{ 
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();            

            car.Make = "Ford";
            car.Model = "Kuga";
            car.Year = 2019;
            car.FuelQuantity = 66;
            car.FuelConsumption = 13;
            car.Drive(2000);
            Console.WriteLine(car.WhoAmI());


        }
    }
}
