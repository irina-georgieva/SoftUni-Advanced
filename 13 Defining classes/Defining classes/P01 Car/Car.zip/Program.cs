﻿using System;

namespace CarManufacturer
{ 
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();            

            car.Make = "Ford";
            car.Model = "Kuga";
            car.Year = 2019;

            Console.WriteLine($"Make: {car.Make}");
            Console.WriteLine($"Model: {car.Model}");
            Console.WriteLine($"Year: {car.Year}");
        }
    }
}
