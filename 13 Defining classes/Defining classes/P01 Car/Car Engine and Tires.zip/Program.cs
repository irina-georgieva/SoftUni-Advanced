﻿using System;
using System.Collections.Generic;

namespace CarManufacturer
{ 
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();            

            car.Make = "Ford";
            car.Model = "Kuga";
            car.Year = 2019;
            car.FuelQuantity = 66;
            car.FuelConsumption = 13;
            car.Drive(2000);
            Console.WriteLine(car.WhoAmI());

            Car firstCar = new Car();
            Car secondCar = new Car("Audi", "A7", 2021);
            Car thirdCar = new Car("BMW", "220i", 2021, 52, 6);

            var engine = new Engine(560, 6300);

            Tire[] tires = new Tire[4];
            Car fourthCar = new Car("Lamborghini", "Urus", 2010, 250, 9, engine, tires);
        }
    }
}
