﻿using System;

namespace CarManufacturer
{ 
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();            

            car.Make = "Ford";
            car.Model = "Kuga";
            car.Year = 2019;
            car.FuelQuantity = 66;
            car.FuelConsumption = 13;
            car.Drive(2000);
            Console.WriteLine(car.WhoAmI());

            Car firstCar = new Car();
            Car secondCar = new Car("Audi", "A7", 2021);
            Car thirdCar = new Car("BMW", "220i", 2021, 52, 6);
        }
    }
}
